/*
From:ITC
6
Pointer related defects
6.1
Bad cast of a function pointer
6.1.3
return type function long and function pointer: float
*/
#include<stdio.h>  
long func_pointer_003_func_001 (long a, int b)
{
	return (a + (long)b);
}

void func_pointer_003 ()
{
	float ret;
	if(1)
	{
		float (*func)(long , int);
		func = (float (*)(long , int ))func_pointer_003_func_001;
		ret = func(1, 2);/*Tool should detect this line as error*/ /*ERROR:Bad function pointer casting*/
	}
}