/*
From:ITC
5
Numerical defects
5.7
Power related errors
5.7.3
One of the elements in an array is out of bounds
*/
#include<stdio.h>          
#include<math.h>            
extern double dsink;        
void pow_related_errors_003()
{
	double arr[]={2.0,1.2,3.9,10^3800,4.0};
	int i;
	double exponent=2;
	double ans;

	for(i=0;i<(sizeof(arr)/sizeof(double));i++)
	{
		double temp=arr[i];
		ans=pow(temp,exponent); /*Tool should detect this line as error*/ /*ERROR:Data Overflow*/
	}
        dsink = ans;
}