/*
From:ITC
6
Pointer related defects
6.1
Bad cast of a function pointer
6.1.2
return type function int and function pointer: void
*/
#include<stdio.h>   
#include<string.h>   
extern int sink;     
int func_pointer_002_func_001(char a)
{
	a++;
	return (a);
}

void func_pointer_002 ()
{
	char buf[10] = "string";
	void (*fptr)(char);
	/* int a; */
	fptr = (void (*)(char ))func_pointer_002_func_001;
	fptr(buf[0]);/*Tool should detect this line as error*/ /*ERROR:Bad function pointer casting*/
}